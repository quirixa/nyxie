const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { getUserDb, all, get, run } = require('../database/userDb');
const { getMessageDb, allMessages, getMessage, runMessage } = require('../database/messageDb');
const { requireAuth } = require('../middleware/auth');
const { isBlocked } = require('../services/blocks');

async function getLatestMessages(roomIds) {
  if (!roomIds.length) return {};
  const msgDb = await getMessageDb();
  const rows = allMessages(msgDb, `
    SELECT m.room_id, m.content, m.nonce, m.msg_type, m.created_at
    FROM messages m
    WHERE m.deleted = 0
      AND m.created_at = (
        SELECT MAX(created_at) FROM messages
        WHERE room_id = m.room_id AND deleted = 0
      )
      AND m.room_id IN (${roomIds.map(() => '?').join(',')})
  `, roomIds);
  const map = {};
  rows.forEach(row => {
    // Voice messages store ciphertext in `content`, which is meaningless
    // as a list preview (and would just show base64 noise), so use a
    // fixed label instead. The client still knows to decrypt+render the
    // real content once the conversation itself is opened.
    const preview = row.msg_type === 'voice' ? '🎤 Voice message' : row.content;
    // `nonce` is passed through as-is: when set, `content` is E2EE
    // ciphertext and the client is expected to decrypt it client-side
    // (it has the keys, the server never does) before displaying it.
    map[row.room_id] = { content: preview, nonce: row.msg_type === 'voice' ? null : row.nonce, msg_type: row.msg_type, created_at: row.created_at };
  });
  return map;
}

router.get('/', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const { server_id } = req.query;

  let rooms;
  if (server_id) {
    rooms = all(db, `
      SELECT r.id, r.name, r.description, r.created_at, r.is_dm,
        (SELECT COUNT(*) FROM room_members rm2 WHERE rm2.room_id = r.id) AS member_count
      FROM rooms r
      JOIN room_members rm ON rm.room_id = r.id
      WHERE r.server_id = ? AND r.is_dm = 0 AND rm.user_id = ?
      ORDER BY r.created_at DESC
    `, [server_id, req.user.id]);
  } else {
    rooms = all(db, `
      SELECT r.id, r.name, r.description, r.created_at, r.is_dm,
        (SELECT COUNT(*) FROM room_members rm2 WHERE rm2.room_id = r.id) AS member_count
      FROM rooms r
      JOIN room_members rm ON rm.room_id = r.id
      WHERE r.is_dm = 1 AND rm.user_id = ?
      ORDER BY r.created_at DESC
    `, [req.user.id]);
    for (const room of rooms) {
      const members = all(db, `SELECT user_id FROM room_members WHERE room_id = ?`, [room.id]);
      const other = members.find(m => m.user_id !== req.user.id);
      if (other) {
        const otherUser = get(db, 'SELECT display_name, username FROM users WHERE id = ?', [other.user_id]);
        room.display_name = otherUser ? (otherUser.display_name || otherUser.username) : 'Unknown';
        room._otherId = other.user_id;
      } else {
        room.display_name = room.name;
      }
    }
  }

  const roomIds = rooms.map(r => r.id);
  const latestMap = await getLatestMessages(roomIds);
  for (const room of rooms) {
    const latest = latestMap[room.id];
    room.last_message = latest ? latest.content : null;
    room.last_message_nonce = latest ? latest.nonce : null;
    room.last_message_type = latest ? latest.msg_type : null;
    room.last_message_at = latest ? latest.created_at : null;
  }

  res.json({ rooms });
});

router.post('/dm', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const { target_user_id } = req.body;
  if (!target_user_id) return res.status(400).json({ error: 'target_user_id required' });
  if (target_user_id === req.user.id) return res.status(400).json({ error: 'Cannot DM yourself' });

  const targetUser = get(db, 'SELECT id, username, display_name FROM users WHERE id = ?', [target_user_id]);
  if (!targetUser) return res.status(404).json({ error: 'User not found' });

  if (isBlocked(db, req.user.id, target_user_id)) {
    return res.status(403).json({ error: 'Unable to start a conversation with this user' });
  }

  const existing = get(db, `
    SELECT r.id FROM rooms r
    JOIN room_members rm1 ON rm1.room_id = r.id AND rm1.user_id = ?
    JOIN room_members rm2 ON rm2.room_id = r.id AND rm2.user_id = ?
    WHERE r.is_dm = 1
    AND (SELECT COUNT(*) FROM room_members WHERE room_id = r.id) = 2
    LIMIT 1
  `, [req.user.id, target_user_id]);

  if (existing) return res.json({ room_id: existing.id });

  const roomId = crypto.randomUUID();
  const now = Date.now();
  run(db, 'INSERT INTO rooms (id, name, description, created_by, created_at, is_dm) VALUES (?, ?, ?, ?, ?, 1)',
    [roomId, `dm-${req.user.id}-${target_user_id}`, '', req.user.id, now]);
  run(db, 'INSERT INTO room_members (room_id, user_id, joined_at) VALUES (?, ?, ?)', [roomId, req.user.id, now]);
  run(db, 'INSERT INTO room_members (room_id, user_id, joined_at) VALUES (?, ?, ?)', [roomId, target_user_id, now]);

  const initiator = { id: req.user.id, username: req.user.username, display_name: req.user.display_name };
  const target    = { id: targetUser.id, username: targetUser.username, display_name: targetUser.display_name || targetUser.username };
  req.app.locals.broadcastToUser(req.user.id,   { type: 'dm_created', room_id: roomId, with_user: target });
  req.app.locals.broadcastToUser(target_user_id, { type: 'dm_created', room_id: roomId, with_user: initiator });

  res.status(201).json({ room_id: roomId });
});

router.get('/:id/messages', requireAuth, async (req, res) => {
  const userDb = await getUserDb();
  const isMember = get(userDb, 'SELECT 1 FROM room_members WHERE room_id = ? AND user_id = ?', [req.params.id, req.user.id]);
  if (!isMember) return res.status(403).json({ error: 'Not a member' });

  const msgDb = await getMessageDb();
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const before = req.query.before ? parseInt(req.query.before) : Date.now() + 1;

  const messages = allMessages(msgDb, `
    SELECT id, room_id, user_id, content, nonce, msg_type, duration, attachments, mentions, created_at, edited_at, deleted
    FROM messages
    WHERE room_id = ? AND created_at < ?
    ORDER BY created_at DESC
    LIMIT ?
  `, [req.params.id, before, limit]);

  const userIds = [...new Set(messages.map(m => m.user_id))];
  let userMap = {};
  if (userIds.length) {
    const placeholders = userIds.map(() => '?').join(',');
    const users = all(userDb, `SELECT id, username, display_name FROM users WHERE id IN (${placeholders})`, userIds);
    users.forEach(u => { userMap[u.id] = u; });
  }

  const enriched = messages.map(m => ({
    ...m,
    attachments: m.attachments ? JSON.parse(m.attachments) : null,
    mentions: m.mentions ? JSON.parse(m.mentions) : null,
    username: userMap[m.user_id]?.username || 'unknown',
    display_name: userMap[m.user_id]?.display_name || userMap[m.user_id]?.username || 'Unknown'
  }));

  res.json({ messages: enriched.reverse() });
});

router.post('/:id/messages', requireAuth, async (req, res) => {
  const userDb = await getUserDb();
  const isMember = get(userDb, 'SELECT 1 FROM room_members WHERE room_id = ? AND user_id = ?', [req.params.id, req.user.id]);
  if (!isMember) return res.status(403).json({ error: 'Not a member' });

  // Blocking only applies to 1:1 DMs — group rooms/channels aren't gated
  // by a two-person block relationship. If the block happened after this
  // DM was created, this is what actually stops new messages going
  // through (creation-time checks in POST /dm only cover new DMs).
  const room = get(userDb, 'SELECT is_dm FROM rooms WHERE id = ?', [req.params.id]);
  if (room && room.is_dm) {
    const other = get(userDb, 'SELECT user_id FROM room_members WHERE room_id = ? AND user_id != ?', [req.params.id, req.user.id]);
    if (other && isBlocked(userDb, req.user.id, other.user_id)) {
      return res.status(403).json({ error: 'You cannot message this user' });
    }
  }

  const { content, ciphertext, nonce, type, duration, attachments } = req.body;
  const msgType = type === 'voice' ? 'voice' : 'text';

  // Attachments come from POST /api/upload as [{ name, url, type }, ...].
  // Validate shape defensively since this is client-controlled JSON that
  // gets stored and later re-rendered (as a link/img src) for other users.
  let cleanAttachments = null;
  if (attachments) {
    if (!Array.isArray(attachments) || attachments.length > 10) {
      return res.status(400).json({ error: 'Invalid attachments' });
    }
    cleanAttachments = attachments.map(a => ({
      name: String(a?.name || 'file').slice(0, 255),
      url: String(a?.url || ''),
      type: String(a?.type || '').slice(0, 100)
    })).filter(a => a.url.startsWith('/uploads/'));
    if (!cleanAttachments.length) cleanAttachments = null;
  }

  // Mentions come from the client as a list of user IDs (resolved from
  // @username against the room's member list — the client has that,
  // the server doesn't when the message is E2EE ciphertext). Re-check
  // membership here rather than trusting the client list outright, and
  // cap it so a message can't be used to spam-notify unrelated users.
  let cleanMentions = null;
  const { mentions } = req.body;
  if (mentions) {
    if (!Array.isArray(mentions) || mentions.length > 20) {
      return res.status(400).json({ error: 'Invalid mentions' });
    }
    const candidateIds = [...new Set(mentions.map(id => String(id)))];
    if (candidateIds.length) {
      const placeholders = candidateIds.map(() => '?').join(',');
      const memberRows = all(userDb, `SELECT user_id FROM room_members WHERE room_id = ? AND user_id IN (${placeholders})`, [req.params.id, ...candidateIds]);
      cleanMentions = memberRows.map(r => r.user_id);
    }
    if (!cleanMentions || !cleanMentions.length) cleanMentions = null;
  }

  if (msgType === 'voice') {
    // Voice messages are E2EE-only — there is no plaintext fallback, so
    // refuse to store one that isn't encrypted rather than silently
    // accepting a voice clip the server (or anyone who dumps the DB)
    // could listen to.
    if (!ciphertext || !nonce) {
      return res.status(400).json({ error: 'Voice messages must be end-to-end encrypted (ciphertext + nonce required)' });
    }
    // Base64-encoded opus/webm clip. ~4MB of base64 covers roughly a
    // couple of minutes of compressed voice, which is a generous cap for
    // a chat voice note; reject anything larger up front.
    if (ciphertext.length > 4_000_000) {
      return res.status(400).json({ error: 'Voice message too long' });
    }
    const msgDuration = Number.isFinite(duration) ? Math.max(0, Math.round(duration)) : null;

    const msgId = crypto.randomUUID();
    const now = Date.now();
    const msgDb = await getMessageDb();
    runMessage(msgDb, 'INSERT INTO messages (id, room_id, user_id, content, nonce, msg_type, duration, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [msgId, req.params.id, req.user.id, ciphertext, nonce, 'voice', msgDuration, now]);

    const message = {
      id: msgId,
      room_id: req.params.id,
      content: ciphertext,
      nonce,
      msg_type: 'voice',
      duration: msgDuration,
      created_at: now,
      user_id: req.user.id,
      username: req.user.username,
      display_name: req.user.display_name
    };

    req.app.locals.broadcast(req.params.id, { type: 'new_message', message });
    return res.status(201).json({ message });
  }

  if (!content && !ciphertext && !cleanAttachments) {
    return res.status(400).json({ error: 'Message content, ciphertext, or attachments required' });
  }
  const msgContent = content ? content.trim() : (ciphertext || '');
  const msgNonce = nonce || null;

  if (!msgContent && !cleanAttachments) return res.status(400).json({ error: 'Message content required' });
  if (msgContent.length > 4000) return res.status(400).json({ error: 'Message too long' });

  const msgId = crypto.randomUUID();
  const now = Date.now();
  const msgDb = await getMessageDb();
  runMessage(msgDb, 'INSERT INTO messages (id, room_id, user_id, content, nonce, msg_type, attachments, mentions, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [msgId, req.params.id, req.user.id, msgContent, msgNonce, 'text', cleanAttachments ? JSON.stringify(cleanAttachments) : null, cleanMentions ? JSON.stringify(cleanMentions) : null, now]);

  const message = {
    id: msgId,
    room_id: req.params.id,
    content: msgContent,
    nonce: msgNonce,
    msg_type: 'text',
    attachments: cleanAttachments,
    mentions: cleanMentions,
    created_at: now,
    user_id: req.user.id,
    username: req.user.username,
    display_name: req.user.display_name
  };

  req.app.locals.broadcast(req.params.id, { type: 'new_message', message });

  // Ping mentioned users directly (not just via the room broadcast above)
  // so the notification/sound fires even if they don't currently have
  // this room open/joined over the websocket.
  if (cleanMentions) {
    for (const uid of cleanMentions) {
      if (uid === req.user.id) continue;
      req.app.locals.broadcastToUser(uid, {
        type: 'mention',
        room_id: req.params.id,
        message_id: msgId,
        from: { id: req.user.id, username: req.user.username, display_name: req.user.display_name }
      });
    }
  }

  res.status(201).json({ message });
});

router.patch('/:roomId/messages/:msgId', requireAuth, async (req, res) => {
  const msgDb = await getMessageDb();
  const msg = getMessage(msgDb, 'SELECT * FROM messages WHERE id = ? AND room_id = ?', [req.params.msgId, req.params.roomId]);
  if (!msg) return res.status(404).json({ error: 'Message not found' });
  if (msg.user_id !== req.user.id) return res.status(403).json({ error: 'Not your message' });
  if (msg.deleted) return res.status(400).json({ error: 'Cannot edit deleted message' });

  const { content } = req.body;
  if (!content || !content.trim()) return res.status(400).json({ error: 'Content required' });

  const now = Date.now();
  runMessage(msgDb, 'UPDATE messages SET content = ?, edited_at = ? WHERE id = ?', [content.trim(), now, msg.id]);

  req.app.locals.broadcast(req.params.roomId, {
    type: 'message_edited',
    message_id: msg.id,
    content: content.trim(),
    edited_at: now
  });
  res.json({ ok: true });
});

router.delete('/:roomId/messages/:msgId', requireAuth, async (req, res) => {
  const msgDb = await getMessageDb();
  const msg = getMessage(msgDb, 'SELECT * FROM messages WHERE id = ? AND room_id = ?', [req.params.msgId, req.params.roomId]);
  if (!msg) return res.status(404).json({ error: 'Message not found' });
  if (msg.user_id !== req.user.id) return res.status(403).json({ error: 'Not your message' });

  runMessage(msgDb, 'UPDATE messages SET deleted = 1, content = \'[deleted]\' WHERE id = ?', [msg.id]);
  req.app.locals.broadcast(req.params.roomId, { type: 'message_deleted', message_id: msg.id });
  res.json({ ok: true });
});

router.post('/:id/leave', requireAuth, async (req, res) => {
  const db = await getUserDb();
  run(db, 'DELETE FROM room_members WHERE room_id = ? AND user_id = ?', [req.params.id, req.user.id]);
  res.json({ ok: true });
});

module.exports = router;