const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { getUserDb, all, get, run } = require('../database/userDb');
const { requireAuth } = require('../middleware/auth');
const { ensureBlocksTable, isBlocked, listBlocked } = require('../services/blocks');
const { effectiveStatus } = require('../services/presence');

// GET /api/friends — list accepted friends (with avatars)
// Blocked users are excluded defensively even though blocking already
// tears down any existing friendship (see POST /block/:id below).
router.get('/', requireAuth, async (req, res) => {
  const db = await getUserDb();
  ensureBlocksTable(db);
  const friends = all(db, `
    SELECT u.id, u.username, u.display_name, u.avatar, u.status, u.last_seen
    FROM friends f
    JOIN users u ON u.id = CASE WHEN f.user_a = ? THEN f.user_b ELSE f.user_a END
    WHERE (f.user_a = ? OR f.user_b = ?) AND f.status = 'accepted'
      AND NOT EXISTS (
        SELECT 1 FROM blocks b
        WHERE (b.blocker_id = ? AND b.blocked_id = u.id) OR (b.blocker_id = u.id AND b.blocked_id = ?)
      )
  `, [req.user.id, req.user.id, req.user.id, req.user.id, req.user.id]);
  // Mask each friend's status the same way any other viewer would see it —
  // an Invisible friend must show as offline here too, and "Online" in the
  // Friends tab means "status !== offline" once this masking is applied
  // (see the tab filter in dashboard.js's renderFriendsList).
  const isUserConnected = req.app.locals.isUserConnected || (() => false);
  friends.forEach(f => { f.status = effectiveStatus(f.status, { connected: isUserConnected(f.id), isSelf: false }); });
  res.json({ friends });
});

// GET /api/friends/requests — pending requests (incoming + outgoing) with avatars
router.get('/requests', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const incoming = all(db, `
    SELECT fr.id, fr.from_id, fr.created_at,
           u.username AS from_username, u.display_name AS from_name, u.avatar AS from_avatar
    FROM friend_requests fr
    JOIN users u ON u.id = fr.from_id
    WHERE fr.to_id = ? AND fr.status = 'pending'
    ORDER BY fr.created_at DESC
  `, [req.user.id]);
  const outgoing = all(db, `
    SELECT fr.id, fr.to_id, fr.created_at,
           u.username AS to_username, u.display_name AS to_name, u.avatar AS to_avatar
    FROM friend_requests fr
    JOIN users u ON u.id = fr.to_id
    WHERE fr.from_id = ? AND fr.status = 'pending'
    ORDER BY fr.created_at DESC
  `, [req.user.id]);
  res.json({ incoming, outgoing });
});

// GET /api/friends/blocked — users I've blocked
router.get('/blocked', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const blocked = listBlocked(db, req.user.id);
  res.json({ blocked });
});

// POST /api/friends/block/:id — block a user.
// Tears down any existing friendship and cancels pending requests between
// the two of you (in either direction) so a stale friendship/request can't
// linger around a block.
router.post('/block/:id', requireAuth, async (req, res) => {
  const db = await getUserDb();
  ensureBlocksTable(db);
  const targetId = req.params.id;

  if (targetId === req.user.id) return res.status(400).json({ error: 'Cannot block yourself' });
  const target = get(db, 'SELECT id FROM users WHERE id = ?', [targetId]);
  if (!target) return res.status(404).json({ error: 'User not found' });

  run(db, `
    DELETE FROM friends
    WHERE (user_a = ? AND user_b = ?) OR (user_a = ? AND user_b = ?)
  `, [req.user.id, targetId, targetId, req.user.id]);

  run(db, `
    UPDATE friend_requests SET status = 'cancelled'
    WHERE status = 'pending' AND ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?))
  `, [req.user.id, targetId, targetId, req.user.id]);

  const blockId = crypto.randomUUID();
  run(db, `
    INSERT OR IGNORE INTO blocks (id, blocker_id, blocked_id, created_at) VALUES (?, ?, ?, ?)
  `, [blockId, req.user.id, targetId, Date.now()]);

  // Let the other side know the friendship ended, same event the normal
  // "remove friend" flow sends — this doesn't reveal that they were
  // specifically blocked, just that they're no longer friends.
  req.app.locals.broadcastToUser(targetId, { type: 'friend_removed', user_id: req.user.id });

  res.json({ ok: true });
});

// DELETE /api/friends/block/:id — unblock
router.delete('/block/:id', requireAuth, async (req, res) => {
  const db = await getUserDb();
  ensureBlocksTable(db);
  run(db, 'DELETE FROM blocks WHERE blocker_id = ? AND blocked_id = ?', [req.user.id, req.params.id]);
  res.json({ ok: true });
});

// POST /api/friends/request — send a friend request
router.post('/request', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const { to_id } = req.body;
  if (!to_id) return res.status(400).json({ error: 'to_id required' });
  if (to_id === req.user.id) return res.status(400).json({ error: 'Cannot friend yourself' });

  const target = get(db, 'SELECT id, username, display_name, avatar FROM users WHERE id = ?', [to_id]);
  if (!target) return res.status(404).json({ error: 'User not found' });

  if (isBlocked(db, req.user.id, to_id)) {
    return res.status(403).json({ error: 'Unable to send a friend request to this user' });
  }

  const already = get(db, `
    SELECT 1 FROM friends
    WHERE ((user_a = ? AND user_b = ?) OR (user_a = ? AND user_b = ?)) AND status = 'accepted'
  `, [req.user.id, to_id, to_id, req.user.id]);
  if (already) return res.status(409).json({ error: 'Already friends' });

  const pending = get(db, `
    SELECT id, from_id FROM friend_requests
    WHERE ((from_id = ? AND to_id = ?) OR (from_id = ? AND to_id = ?)) AND status = 'pending'
  `, [req.user.id, to_id, to_id, req.user.id]);
  if (pending) {
    if (pending.from_id === to_id) {
      run(db, 'UPDATE friend_requests SET status = ? WHERE id = ?', ['accepted', pending.id]);
      const friendId = crypto.randomUUID();
      run(db, 'INSERT OR IGNORE INTO friends (id, user_a, user_b, status, created_at) VALUES (?, ?, ?, \'accepted\', ?)',
          [friendId, req.user.id, to_id, Date.now()]);
      // Fetch the friend's full profile (including avatar)
      const me = get(db, 'SELECT id, username, display_name, avatar, status, last_seen FROM users WHERE id = ?', [req.user.id]);
      me.status = effectiveStatus(me.status, { connected: (req.app.locals.isUserConnected || (() => false))(me.id), isSelf: false });
      req.app.locals.broadcastToUser(to_id, { type: 'friend_accepted', request_id: pending.id, friend: me });
      return res.json({ ok: true, auto_accepted: true });
    }
    return res.status(409).json({ error: 'Request already sent' });
  }

  const reqId = crypto.randomUUID();
  run(db, 'INSERT INTO friend_requests (id, from_id, to_id, status, created_at) VALUES (?, ?, ?, \'pending\', ?)',
      [reqId, req.user.id, to_id, Date.now()]);

  // Send the request notification with avatar
  const fromUser = get(db, 'SELECT id, username, display_name, avatar FROM users WHERE id = ?', [req.user.id]);
  req.app.locals.broadcastToUser(to_id, {
    type: 'friend_request',
    request: {
      id: reqId,
      from_id: req.user.id,
      created_at: Date.now(),
      from_username: fromUser.username,
      from_name: fromUser.display_name,
      from_avatar: fromUser.avatar
    }
  });
  res.status(201).json({ ok: true, request_id: reqId });
});

// POST /api/friends/requests/:id/accept
router.post('/requests/:id/accept', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const fr = get(db, 'SELECT * FROM friend_requests WHERE id = ? AND to_id = ? AND status = ?',
      [req.params.id, req.user.id, 'pending']);
  if (!fr) return res.status(404).json({ error: 'Request not found' });

  run(db, 'UPDATE friend_requests SET status = ? WHERE id = ?', ['accepted', fr.id]);
  const friendId = crypto.randomUUID();
  run(db, 'INSERT OR IGNORE INTO friends (id, user_a, user_b, status, created_at) VALUES (?, ?, ?, \'accepted\', ?)',
      [friendId, fr.from_id, fr.to_id, Date.now()]);

  const me = get(db, 'SELECT id, username, display_name, avatar, status, last_seen FROM users WHERE id = ?', [req.user.id]);
  me.status = effectiveStatus(me.status, { connected: (req.app.locals.isUserConnected || (() => false))(me.id), isSelf: false });
  req.app.locals.broadcastToUser(fr.from_id, { type: 'friend_accepted', request_id: fr.id, friend: me });
  res.json({ ok: true });
});

// POST /api/friends/requests/:id/decline
router.post('/requests/:id/decline', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const fr = get(db, 'SELECT * FROM friend_requests WHERE id = ? AND to_id = ? AND status = ?',
      [req.params.id, req.user.id, 'pending']);
  if (!fr) return res.status(404).json({ error: 'Request not found' });
  run(db, 'UPDATE friend_requests SET status = ? WHERE id = ?', ['declined', fr.id]);
  req.app.locals.broadcastToUser(fr.from_id, { type: 'friend_request_declined', request_id: fr.id });
  res.json({ ok: true });
});

// DELETE /api/friends/requests/:id — cancel outgoing request
router.delete('/requests/:id', requireAuth, async (req, res) => {
  const db = await getUserDb();
  const fr = get(db, 'SELECT * FROM friend_requests WHERE id = ? AND from_id = ? AND status = ?',
      [req.params.id, req.user.id, 'pending']);
  if (!fr) return res.status(404).json({ error: 'Request not found' });
  run(db, 'UPDATE friend_requests SET status = ? WHERE id = ?', ['cancelled', fr.id]);
  req.app.locals.broadcastToUser(fr.to_id, { type: 'friend_request_cancelled', request_id: fr.id });
  res.json({ ok: true });
});

// DELETE /api/friends/:id — remove friend
router.delete('/:id', requireAuth, async (req, res) => {
  const db = await getUserDb();
  run(db, `
    DELETE FROM friends
    WHERE (user_a = ? AND user_b = ?) OR (user_a = ? AND user_b = ?)
  `, [req.user.id, req.params.id, req.params.id, req.user.id]);
  req.app.locals.broadcastToUser(req.params.id, { type: 'friend_removed', user_id: req.user.id });
  res.json({ ok: true });
});

module.exports = router;