// utils.js — small helpers shared by every view. Classic script (no
// import/export) so every other app script can call these directly,
// same as the rest of the app's module set (see state.js for why).

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// identicon — GitHub-style generated default avatar. Used wherever a user has
// no uploaded avatar. Deterministic: the same seed (always the user's id) gives
// the same picture everywhere. 5x5 grid, left-right mirrored, one colour per
// seed on a light-grey tile with enough margin to survive a round crop. Returns an SVG data: URI (no network, no assets).
const _identiconCache = new Map();
function identiconUrl(seed) {
  seed = String(seed == null ? '' : seed);
  const hit = _identiconCache.get(seed);
  if (hit) return hit;
  let h = 1779033703 ^ seed.length;
  for (let i = 0; i < seed.length; i++) {
    h = Math.imul(h ^ seed.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  h = Math.imul(h ^ (h >>> 16), 2246822507);
  h = Math.imul(h ^ (h >>> 13), 3266489909);
  let s = (h ^ (h >>> 16)) >>> 0;
  const rand = () => {            // mulberry32
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  const hue = Math.floor(rand() * 360);
  const rect = (x, y) => `<rect x="${x + 1.1}" y="${y + 1.1}" width="1" height="1"/>`;
  let cells = '', on = 0;
  for (let y = 0; y < 5; y++) {
    for (let x = 0; x < 3; x++) {
      if (rand() < 0.5) { cells += rect(x, y) + (x < 2 ? rect(4 - x, y) : ''); on += x < 2 ? 2 : 1; }
    }
  }
  if (on < 7) for (let y = 0; y < 5; y++) cells += rect(2, y);   // never leave it nearly blank
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 7.2 7.2" shape-rendering="crispEdges"><rect width="7.2" height="7.2" fill="#f0f0f0"/><g fill="hsl(${hue},65%,50%)">${cells}</g></svg>`;
  const url = 'data:image/svg+xml,' + encodeURIComponent(svg);
  _identiconCache.set(seed, url);
  return url;
}
function identiconImg(seed) {
  return `<img class="identicon" src="${identiconUrl(seed)}" alt="" draggable="false" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;display:block;" />`;
}

function escapeJs(str) {
  if (str === null || str === undefined) return '';
  return String(str).replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/\r/g, '\\r').replace(/\n/g, '\\n');
}

function escapeRegExp(str) {
  return String(str).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// highlightMentions — wraps @username occurrences in already-escaped
// message HTML with a styled span. Takes ESCAPED content (i.e. run
// escapeHtml() first) so this never introduces raw HTML from the
// message text itself — it only wraps text that literally matches one
// of the given members' usernames, and the username itself is
// re-escaped before being placed in the output.
//
// `members` is [{id, username}] — the room's member list (or however
// many of them are known), used only to know which @tokens are real
// users worth highlighting, not to render anything unescaped.
function highlightMentions(escapedContent, members, selfId) {
  if (!members || !members.length) return escapedContent;
  let html = escapedContent;
  const sorted = [...members]
    .filter(m => m && m.username)
    .sort((a, b) => b.username.length - a.username.length);
  for (const m of sorted) {
    const uname = escapeHtml(m.username);
    const re = new RegExp(`(^|[^\\w@])@${escapeRegExp(uname)}(?!\\w)`, 'g');
    html = html.replace(re, (match, pre) =>
      `${pre}<span class="mention${m.id === selfId ? ' mention-me' : ''}" data-user-id="${m.id}">@${uname}</span>`);
  }
  return html;
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Toast — looks for a #toast (dashboard) or #toastMsg (auth pages)
// element in whichever view is currently mounted.
let _toastTimeout = null;
function toast(message, isError) {
  const el = document.getElementById('toast') || document.getElementById('toastMsg');
  if (!el) return;
  if (_toastTimeout) clearTimeout(_toastTimeout);
  el.textContent = message;
  el.style.opacity = '1';
  if (el.id === 'toastMsg') {
    if (isError) {
      el.style.background = '#2c1a1a';
      el.style.borderColor = '#aa4a4a';
      el.style.color = '#ffc6c6';
    } else {
      el.style.background = '#1e2a1e';
      el.style.borderColor = '#4f7a4f';
      el.style.color = '#c6ffc6';
    }
  }
  _toastTimeout = setTimeout(() => { el.style.opacity = '0'; }, 4000);
}

function formatTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

function formatDay(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const now = new Date();
  const isToday = d.toDateString() === now.toDateString();
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday = d.toDateString() === yesterday.toDateString();
  if (isToday) return 'Today';
  if (isYesterday) return 'Yesterday';
  return d.toLocaleDateString([], { month: 'long', day: 'numeric', year: d.getFullYear() !== now.getFullYear() ? 'numeric' : undefined });
}

function debounce(fn, wait) {
  let t = null;
  return function debounced(...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

// ReservedUsernames — client-side mirror of the server's reserved-list
// check (server/services/reservedUsernames.js), used only to give
// instant feedback before a round trip; the server is what actually
// enforces this. Same load-with-fallback shape as the emoji engine in
// dashboard.js (fetch a public JSON file once, cache it, fall back to a
// small built-in list if the fetch fails) so both registration and the
// settings "change username" flow can share one source instead of each
// hardcoding the list.
const ReservedUsernames = (() => {
  let list = null;
  let loadPromise = null;
  // No hardcoded fallback list — the JSON file is the only source of
  // truth. If the fetch fails, nothing is treated as reserved here;
  // the server-side check (which enforces this for real) is what
  // actually stops registration, this is just instant client feedback.

  function load() {
    if (list) return Promise.resolve(list);
    if (loadPromise) return loadPromise;
    loadPromise = fetch('/assets/reserved-usernames.json')
      .then(r => { if (!r.ok) throw new Error(); return r.json(); })
      .then(data => {
        list = Array.isArray(data) ? data.map(s => String(s).toLowerCase()) : [];
        return list;
      })
      .catch(() => { list = []; return list; });
    return loadPromise;
  }

  async function isReserved(username) {
    const reserved = await load();
    return reserved.includes(String(username || '').toLowerCase());
  }

  return { load, isReserved };
})();
// Kick off the load immediately (fire-and-forget) so it's already
// cached by the time someone actually submits a form — the `await` in
// auth.js/settings.js is just a safety net for whichever request wins.
ReservedUsernames.load();

// `url + '?t=' + Date.now()` pattern. Appending a fresh timestamp on
// *every* render defeated the browser cache entirely, so avatars/banners
// re-fetched from the network on every navigation (visible flash/reload
// each time). Instead we memoize one cache-busting token per distinct
// URL, so repeated renders of the same URL reuse the same token (cache
// hit), and only actual uploads (which pass bump=true) get a fresh one.
const _mediaCacheTokens = new Map();
function versionedMediaUrl(url, bump) {
  if (!url) return '';
  const raw = String(url).trim();
  try {
    const parsed = new URL(raw, window.location.origin);
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return '';
    const normalized = parsed.href;
    if (bump || !_mediaCacheTokens.has(normalized)) _mediaCacheTokens.set(normalized, Date.now());
    parsed.searchParams.set('v', String(_mediaCacheTokens.get(normalized)));
    return parsed.href.replace(/[\'\"\\()\r\n]/g, ch => '%' + ch.charCodeAt(0).toString(16).padStart(2, '0'));
  } catch (_) {
    return '';
  }
}
